/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Boolean.parseBoolean;
import java.sql.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Cliente;
import modelo.ClienteDAO;
import modelo.Compra;
import modelo.CompraDAO;
import modelo.DetalleCompraDAO;
import modelo.DetalleVenta;
import modelo.DetalleVentaDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Proveedor;
import modelo.ProveedorDAO;
import modelo.Sucursal;
import modelo.SucursalDAO;
import modelo.Sucursal_has_Compra;
import modelo.Sucursal_has_CompraDAO;
import modelo.TipoCliente;
import modelo.TipoClienteDAO;
import modelo.TipoEmpleado;
import modelo.TipoEmpleadoDAO;
import modelo.TipoVehiculo;
import modelo.TipoVehiculoDAO;
import modelo.Vehiculo;
import modelo.VehiculoDAO;
import modelo.Venta;
import modelo.VentaDAO;

/**
 *
 * @author DELL
 */
public class Controlador extends HttpServlet {

    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDao = new EmpleadoDAO();
    Vehiculo vehiculo = new Vehiculo();
    VehiculoDAO vehiculoDao = new VehiculoDAO();
    Proveedor proveedor = new Proveedor();
    ProveedorDAO proveedorDao = new ProveedorDAO();
    int codEmpleado;
    int codSucursal;
    Sucursal sucursal = new Sucursal();
    SucursalDAO sucursalDao = new SucursalDAO();
    Compra compra = new Compra();
    CompraDAO compraDao = new CompraDAO();
    Sucursal_has_Compra sucursal_compra = new Sucursal_has_Compra();
    Sucursal_has_CompraDAO sucursal_compraDao = new Sucursal_has_CompraDAO();
    TipoEmpleado tipoempleado = new TipoEmpleado();
    TipoEmpleadoDAO tipoEmpleadoDao = new TipoEmpleadoDAO();
    DetalleVenta detalleVenta = new DetalleVenta();
    DetalleVentaDAO detalleVentaDao = new DetalleVentaDAO();
    DetalleCompraDAO detalleCompraDao = new DetalleCompraDAO();
     Venta venta = new Venta();
    VentaDAO ventaDao =  new VentaDAO();
    int codVenta;
    Cliente cliente = new Cliente();
    ClienteDAO clienteDao = new ClienteDAO();
    TipoCliente tipoCliente = new TipoCliente();
    TipoClienteDAO tipoClienteDao = new TipoClienteDAO();
    int codTipoCliente;
    TipoVehiculo tipoV = new TipoVehiculo();
    TipoVehiculoDAO tipoVDao = new TipoVehiculoDAO();
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if (menu.equals("Principal")) {
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        } else if (menu.equals("Empleado")) {
            switch (accion) {
                case "Listar":
                    List listaEmpleados = empleadoDao.listar();
                    request.setAttribute("empleados", listaEmpleados);
                    List listaSucursales = sucursalDao.listar();
                    request.setAttribute("sucursales",listaSucursales);
                    List listaTipoEmpleado = tipoEmpleadoDao.listar();
                    request.setAttribute("tipoempleado", listaTipoEmpleado);
                    break;
                case "Agregar":
                    String DPI = request.getParameter("txtDPIEmpleado");
                    String primer = request.getParameter("txtPrimerNombre");
                    String otros = request.getParameter("txtOtrosNombres");
                    String ape = request.getParameter("txtApellidos");
                    String tel = request.getParameter("txtTelefono");
                    String dire = request.getParameter("txtDireccion");
                    Boolean est = Boolean.parseBoolean(request.getParameter("txtEstado"));
                    String user = request.getParameter("txtUsuario");
                    int sucu = Integer.parseInt(request.getParameter("cmbSucursal"));
                    int tipo = Integer.parseInt(request.getParameter("cmbTipoEm"));
                    empleado.setDPIEmpleado(DPI);
                    empleado.setPrimerNombre(primer);
                    empleado.setOtrosNombres(otros);
                    empleado.setApellidos(ape);
                    empleado.setTelefonoEmpleado(tel);
                    empleado.setDireccionEmpleado(dire);
                    empleado.setEstadoEmpleado(true);
                    empleado.setUsuario(user);
                    empleado.setCodigoSucursal(sucu);
                    empleado.setCodigoTipoEmpleado(tipo);
                    empleadoDao.agregar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    Empleado e = empleadoDao.listaCodigoEmpleado(codEmpleado);
                    request.setAttribute("empleado", e);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    String DPIactu = request.getParameter("txtDPIEmpleado");
                    String primeractu = request.getParameter("txtPrimerNombre");
                    String otrosactu = request.getParameter("txtOtrosNombres");
                    String apeactu = request.getParameter("txtApellidos");
                    String telactu = request.getParameter("txtTelefono");
                    String direactu = request.getParameter("txtDireccion");
                    Boolean estactu = Boolean.parseBoolean(request.getParameter("txtEstado"));
                    String useractu = request.getParameter("txtUsuario");
                    empleado.setDPIEmpleado(DPIactu);
                    empleado.setPrimerNombre(primeractu);
                    empleado.setOtrosNombres(otrosactu);
                    empleado.setApellidos(apeactu);
                    empleado.setTelefonoEmpleado(telactu);
                    empleado.setDireccionEmpleado(direactu);
                    empleado.setEstadoEmpleado(estactu);
                    empleado.setUsuario(useractu);
                    empleado.setCodigoEmpleado(codEmpleado);
                    empleadoDao.actualizar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    empleadoDao.eliminar(codEmpleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Empleado.jsp").forward(request, response);
            //Sucursal
        }  else if (menu.equals("Sucursal")) {
            switch (accion) {
                case "Listar":
                    List listaSucursales = sucursalDao.listar();
                    request.setAttribute("sucursales", listaSucursales);
                    break;
                case "Agregar":
                    String nombreSucursal = request.getParameter("txtNombreSucursal");
                    String direccion = request.getParameter("txtDireccion");
                    String telefonoSucursal = request.getParameter("txtTelefonoSucursal");
                    String correoSucursal = request.getParameter("txtCorreoSucursal");
                    boolean estadoSucursal = Boolean.valueOf(request.getParameter("txtEstadoSucursal"));
                    sucursal.setNombreSucursal(nombreSucursal);
                    sucursal.setDireccion(direccion);
                    sucursal.setTelefonoSucursal(telefonoSucursal);
                    sucursal.setCorreoSucursal(correoSucursal);
                    sucursal.setEstadoSucursal(estadoSucursal);
                    sucursalDao.agregar(sucursal);
                    request.getRequestDispatcher("Controlador?menu=Sucursal&accion=Listar").forward(request, response);
                    break;
                    //Editar de sucursal
            case "Editar":
                    codSucursal = Integer.parseInt(request.getParameter("codigoSucursal"));
                    Sucursal s = sucursalDao.listaCodigoSucursal(codSucursal);
                    request.setAttribute("sucursal", s);
                    request.getRequestDispatcher("Controlador?menu=Sucursal&accion=Listar").forward(request, response);
                    break;
            case "Actualizar":
                    String nombreSucu = request.getParameter("txtNombreSucursal");
                    String dire = request.getParameter("txtDireccion");
                    String telefonoSucu = request.getParameter("txtTelefonoSucursal");
                    String correoSucu = request.getParameter("txtCorreoSucursal");
                    Boolean estadoSucu = parseBoolean(request.getParameter("txtEstadoSucursal"));
                    sucursal.setNombreSucursal(nombreSucu);
                    sucursal.setDireccion(dire);
                    sucursal.setTelefonoSucursal(telefonoSucu);
                    sucursal.setCorreoSucursal(correoSucu);
                    sucursal.setEstadoSucursal(estadoSucu);
                    sucursal.setCodigoSucursal(codSucursal);
                    sucursalDao.actualizar(sucursal);
                    request.getRequestDispatcher("Controlador?menu=Sucursal&accion=Listar").forward(request, response);
                    break;
            case "Eliminar":
                    codSucursal = Integer.parseInt(request.getParameter("codigoSucursal"));
                    sucursalDao.eliminar(codSucursal);
                    request.getRequestDispatcher("Controlador?menu=Sucursal&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Sucursal.jsp").forward(request, response);
        } else if (menu.equals("Vehiculo")) {
            switch (accion) {
                case "Listar":
                    List listaVehiculos = vehiculoDao.listar();
                    request.setAttribute("vehiculos", listaVehiculos);//Key-Value para meter los datos en el jsp.
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Vehiculo.jsp").forward(request, response);
        } else if (menu.equals("Proveedor")) {
            switch (accion) {
                case "Listar":
                    List listaProveedor = proveedorDao.listar();
                    request.setAttribute("proveedores", listaProveedor);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Proveedor.jsp").forward(request, response);
        } else if (menu.equals("Compra")) {
            switch (accion) {
                case "Listar":
                    List listaCompra = compraDao.listar();
                    request.setAttribute("compras", listaCompra);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Compra.jsp").forward(request, response);
        } else if (menu.equals("Sucursal_has_Compra")) {
            switch (accion) {
                case "Listar":
                    List listaSucursalCompra = sucursal_compraDao.listar();
                    request.setAttribute("sucursales_has_compras", listaSucursalCompra);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Sucursal_has_Compra.jsp").forward(request, response);
        } else if (menu.equals("TipoEmpleado")) {
            switch (accion) {
                case "Listar":
                    List TipoEmpleado = tipoEmpleadoDao.listar();
                    request.setAttribute("tipoempleado", TipoEmpleado);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("TipoEmpleado.jsp").forward(request, response);
        } else if (menu.equals("DetalleVenta")) {
            switch (accion) {
                case "Listar":
                    List DetalleVenta = detalleVentaDao.listar();
                    request.setAttribute("detalleVentas", DetalleVenta);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("DetalleVenta.jsp").forward(request, response);
        } else if (menu.equals("DetalleCompra")){
            switch (accion) {
                case "Listar":
                    List DetalleCompra = detalleCompraDao.listar();
                    request.setAttribute("detallecompra", DetalleCompra);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("DetalleCompra.jsp").forward(request, response);
        }else if (menu.equals("Venta")){
            switch(accion){
                case "Listar":
                    List listaVentas = ventaDao.listarVenta();
                    request.setAttribute("ventas", listaVentas);
                    List listaEmpleado = empleadoDao.listar();
                    request.setAttribute("empleados", listaEmpleado);
                    List listaCliente = clienteDao.listar();
                    request.setAttribute("clientes", listaCliente);
                    break;
                case "Agregar":
                    String fecha = request.getParameter("txtFechaVenta");
                    String hora = request.getParameter("txtHoraVenta");
                    Double total = Double.valueOf(request.getParameter("txtTotalVenta"));
                    Boolean estado = Boolean.valueOf(request.getParameter("txtEstadoVenta"));
                    int codEmpleado = Integer.parseInt(request.getParameter("txtCodigoEmpleado"));
                    int codCliente = Integer.parseInt(request.getParameter("txtCodigoCliente"));
                    venta.setFechaVenta(Date.valueOf(fecha));
                    venta.setHoraVenta(hora);
                    venta.setTotalVenta(total);
                    venta.setEstadoVenta(estado);
                    venta.setCodigoEmpleado(codEmpleado);
                    venta.setCodigoCliente(codCliente);
                    ventaDao.agregarVenta(venta);
                    request.getRequestDispatcher("Controlador?menu=Venta&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    codVenta = Integer.parseInt(request.getParameter("codigoVenta"));
                    Venta v = ventaDao.buscarVenta(codVenta);
                    request.setAttribute("venta", v);
                    request.getRequestDispatcher("Controlador?menu=Venta&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    String fechas = request.getParameter("txtFechaVenta");
                    String horas = request.getParameter("txtHoraVenta");
                    Double totales = Double.valueOf(request.getParameter("txtTotalVenta"));
                    Boolean estados = Boolean.valueOf(request.getParameter("txtEstadoVenta"));
                    int codEmpleados = Integer.parseInt(request.getParameter("txtCodigoEmpleado"));
                    int codClientes = Integer.parseInt(request.getParameter("txtCodigoCliente"));
                    venta.setFechaVenta(Date.valueOf(fechas));
                    venta.setHoraVenta(horas);
                    venta.setTotalVenta(totales);
                    venta.setEstadoVenta(estados);
                    venta.setCodigoEmpleado(codEmpleados);  
                    venta.setCodigoCliente(codClientes);
                    venta.setCodigoVenta(codVenta);
                    ventaDao.editarVenta(venta);
                    request.getRequestDispatcher("Controlador?menu=Venta&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codVenta = Integer.parseInt(request.getParameter("codigoVenta"));
                    ventaDao.eliminarVenta(codVenta);
                    request.getRequestDispatcher("Controlador?menu=Venta&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("WebVenta.jsp").forward(request, response);
        }else if (menu.equals("Cliente")){
            switch(accion){
                case "Listar":
                    List listaClientes = clienteDao.listar();
                    request.setAttribute("clientes", listaClientes);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
            }
            request.getRequestDispatcher("Cliente.jsp").forward(request, response);
        }else if (menu.equals("TipoCliente")){
            switch(accion){
            case "Listar":
                    List listaTipoClientes = tipoClienteDao.listar();
                    request.setAttribute("tipoClientes", listaTipoClientes);
                    break;
                case "Agregar":
                    String tipo = request.getParameter("txtTipoCliente");
                    String descripcion = request.getParameter("txtDescripcion");
                    boolean estado = Boolean.parseBoolean(request.getParameter("txtEstado"));
                    tipoCliente.setTipoCliente(tipo);
                    tipoCliente.setDescripcion(descripcion);
                    tipoCliente.setEstadoTipoCliente(estado);
                    tipoClienteDao.agregar(tipoCliente);
                    request.getRequestDispatcher("Controlador?menu=TipoCliente&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    codTipoCliente = Integer.parseInt(request.getParameter("codigoTipoCliente"));
                    TipoCliente tp = tipoClienteDao.listarTipoCliente(codTipoCliente);
                    request.setAttribute("tipoCliente", tp); 
                    request.getRequestDispatcher("Controlador?menu=TipoCliente&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    String tipoCli = request.getParameter("txtTipoCliente");
                    String descripcionCli = request.getParameter("txtDescripcion");
                    boolean estadoCli = Boolean.parseBoolean(request.getParameter("txtEstado"));
                    tipoCliente.setTipoCliente(tipoCli);
                    tipoCliente.setDescripcion(descripcionCli);
                    tipoCliente.setEstadoTipoCliente(estadoCli);
                    tipoCliente.setCodigoTipoCliente(codTipoCliente);
                    tipoClienteDao.actualizar(tipoCliente);
                    request.getRequestDispatcher("Controlador?menu=TipoCliente&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codTipoCliente = Integer.parseInt(request.getParameter("codigoTipoCliente"));
                    tipoClienteDao.eliminar(codTipoCliente);
                    request.getRequestDispatcher("Controlador?menu=TipoCliente&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("TipoCliente.jsp").forward(request, response);
        }else if(menu.equals("TipoVehiculo")){
            switch(accion){
                case "Listar":
                    List listaTipoVehiculo = tipoVDao.listar();
                    request.setAttribute("tipoVehiculo", listaTipoVehiculo);
                    break;
                case "Agregar":
                    break;
                case "Editar":
                    break;
                case "Actualizar":
                    break;
                case "Eliminar":
                    break;
                    
            }
            request.getRequestDispatcher("TipoVehiculo.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
