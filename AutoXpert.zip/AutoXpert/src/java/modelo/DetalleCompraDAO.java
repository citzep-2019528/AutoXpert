package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DetalleCompraDAO{
	Conexion cn = new Conexion();
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	int resp;

	public List listar(){
		String sql = "Select * from detalleCompra";
		List<DetalleCompra> listaDetalleCompra = new ArrayList<>();
		try{
			con = cn.Conexion();
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				DetalleCompra dc = new DetalleCompra();
				dc.setCodigoDetalleCompra(rs.getInt(1));
				dc.setCodigoVehiculo(rs.getInt(2));
				dc.setCantidadDetalleCompra(rs.getInt(3));
				dc.setPrecioDetalleCompra(rs.getDouble(4));
				dc.setCodigoCompra(rs.getInt(5));
                                listaDetalleCompra.add(dc);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaDetalleCompra;
	}

	public int agregar(DetalleCompra detc){
		String sql = "insert into DetalleCompra (codigoVehiculo,  cantidadDetalleCompra, precioDetalleCompra, codigoCompra ) values (?,?,?,?)";
		try{
			con = cn.Conexion();
			ps = con.prepareStatement(sql);
			ps.setInt(1, detc.getCodigoDetalleCompra());
			ps.setInt(2, detc.getCantidadDetalleCompra());
			ps.setDouble(3, detc.getPrecioDetalleCompra());
			ps.setInt(4, detc.getCodigoCompra());
		} catch (Exception e){
			e.printStackTrace();
		}
		return resp;
	}

	public DetalleCompra listarCodigoDetalleCompra(int id){
		DetalleCompra detc = new DetalleCompra();
		String sql = "Select * from DetalleCompra where codigoDetalleCompra = " + id;
		try {
			con = cn.Conexion();
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				detc.setCodigoVehiculo(rs.getInt(2));
				detc.setCantidadDetalleCompra(rs.getInt(3));
				detc.setPrecioDetalleCompra(rs.getDouble(4));
				detc.setCodigoCompra(rs.getInt(5));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return detc;
	}

	public int actualizar(DetalleCompra detc){
		String sql = "update detalleCompra set codigoDetalleCompra = ?, codigoVehiculo = ?, cantidadDetalleCompra = ? , precioDetalleCompra = ?, codigoCompra = ?" + "where codigoDetalleCompra = ?";
		try{
			con = cn.Conexion();
			ps = con.prepareStatement(sql);
			ps.setInt(1, detc.getCodigoDetalleCompra());
			ps.setInt(2, detc.getCodigoVehiculo());
			ps.setInt(3, detc.getCantidadDetalleCompra());
			ps.setDouble(4, detc.getPrecioDetalleCompra());
			ps.setInt(5, detc.getCodigoCompra());
			ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}
		return resp;
	}

	public void eliminar(int id){
		String sql = "delete from DetalleCompra where codigoDetalleCompra = " + id;
		try{
			con = cn.Conexion();
			ps = con.prepareStatement(sql);
			ps.executeQuery();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}