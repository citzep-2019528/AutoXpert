/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Cliente;
import modelo.ClienteDAO;
import modelo.Compra;
import modelo.CompraDAO;
import modelo.DetalleCompra;
import modelo.DetalleCompraDAO;
import modelo.DetalleVenta;
import modelo.DetalleVentaDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Proveedor;
import modelo.ProveedorDAO;
import modelo.Sucursal;
import modelo.SucursalDAO;
import modelo.Sucursal_has_Compra;
import modelo.Sucursal_has_CompraDAO;
import modelo.TipoCliente;
import modelo.TipoClienteDAO;
import modelo.TipoEmpleado;
import modelo.TipoEmpleadoDAO;
import modelo.TipoVehiculo;
import modelo.TipoVehiculoDAO;
import modelo.Vehiculo;
import modelo.VehiculoDAO;
import modelo.Venta;
import modelo.VentaDAO;

/**
 *
 * @author DELL
 */
public class Controlador extends HttpServlet {
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDao = new EmpleadoDAO();
    TipoEmpleado tEmpleado = new TipoEmpleado();
    TipoEmpleadoDAO tEmpleadoDao = new TipoEmpleadoDAO();
    Venta venta = new Venta();
    VentaDAO ventaDao =  new VentaDAO();
    DetalleVenta dVenta = new DetalleVenta();
    DetalleVentaDAO dVentaDao = new DetalleVentaDAO();
    Cliente cliente = new Cliente();
    ClienteDAO clienteDao = new ClienteDAO();
    TipoCliente tCliente = new TipoCliente();
    TipoClienteDAO tClienteDao =  new TipoClienteDAO();
    Vehiculo vehiculo =  new Vehiculo();
    VehiculoDAO vehiculoDao = new VehiculoDAO();
    TipoVehiculo tVehiculo = new TipoVehiculo();
    TipoVehiculoDAO tVehiculoDao =  new TipoVehiculoDAO();
    Compra compra = new Compra();
    CompraDAO compraDao = new CompraDAO();
    DetalleCompra dCompra= new DetalleCompra();
    DetalleCompraDAO dCompraDao = new DetalleCompraDAO();
    Proveedor proveedor =new Proveedor();
    ProveedorDAO proveedorDao = new ProveedorDAO();
    Sucursal sucursal = new Sucursal();
    SucursalDAO sucursalDao = new SucursalDAO();
    Sucursal_has_Compra has = new Sucursal_has_Compra();
    Sucursal_has_CompraDAO hasDao = new Sucursal_has_CompraDAO();
    int codEmpleado;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        if(menu.equals("Principal")){
            request.getRequestDispatcher("Principal.jsp").forward(request, response);   
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
